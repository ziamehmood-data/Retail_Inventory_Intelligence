# Data Quality Report
_Generated 2026-07-27 05:47 — RIIP pipeline_

**Overall gate:** ✅ PASSED  
**Overall pass rate:** 100.00%

## 1. Cleaning actions (RAW → processed)

| Table | Rows in | Rows out | Duplicates removed | Prices imputed |
|---|---:|---:|---:|---:|
| fact_sales | 40,344 | 40,184 | 160 | 401 |

## 2. Validation checks (on cleaned data)

| Check | Critical | Violations | Pass rate | Result |
|---|:--:|---:|---:|:--:|
| sales.product_key -> dim_product | yes | 0 | 100.0% | ✅ |
| sales.location_key -> dim_location | yes | 0 | 100.0% | ✅ |
| snapshot.product_key -> dim_product | yes | 0 | 100.0% | ✅ |
| po.supplier_key -> dim_supplier | yes | 0 | 100.0% | ✅ |
| dim_product.sku unique | yes | 0 | 100.0% | ✅ |
| dim_product.product_key unique | yes | 0 | 100.0% | ✅ |
| sales.unit_price not null | yes | 0 | 100.0% | ✅ |
| sales.units_sold_qty > 0 | yes | 0 | 100.0% | ✅ |
| product price >= cost | no | 0 | 100.0% | ✅ |
| snapshot.on_hand_qty >= 0 | yes | 0 | 100.0% | ✅ |
| po.OTIF = (on-time AND in-full) | no | 0 | 100.0% | ✅ |
| po.received_qty <= ordered_qty | no | 0 | 100.0% | ✅ |

## 3. Issues requiring attention

_No violations detected. All checks passed._

## 4. Interpretation

The cleaning stage removed the injected duplicate rows and imputed the injected missing prices from the product catalog. Post-clean validation confirms referential integrity, key uniqueness, completeness, and business-rule consistency. The warehouse load may proceed only while the gate reads PASSED.
# KPI Report
_Generated 2026-07-27 05:47 — RIIP automated report_

| KPI | Value |
|---|---:|
| Total Revenue | $10,413,649 |
| Gross Margin % | 47.0% |
| Current Inventory Value | $2,011,013 |
| Inventory Turnover | 2.72x |
| Days Inventory Outstanding | 134 days |
| GMROI | 2.42 |
| Stock-out Rate | 2.8% |
| Dead-stock % (value) | 7.3% |
| Annual Carrying Cost | $506,488 |
| Supplier OTIF % | 69.1% |
| Average Lead Time | 13.0 days |

> Definitions follow the BRD metric catalogue (Section 6). Turnover = COGS ÷ average inventory value; GMROI = gross margin ÷ average inventory cost; dead stock = value with no movement in 180 days; carrying cost at 25%.
# Exploratory Data Analysis

_Rows: sales=40,184, snapshot=293,040, PO=4,775_

## Key observations

- **Seasonality** is visible: revenue peaks in the Nov–Dec window.
- **Pareto holds**: the top 20% of SKUs drive **68%** of revenue — this is what justifies ABC management.
- **Supplier reliability spreads** cleanly by tier (Gold → Bronze), confirming the engineered OTIF signal.
- **Stock-out rate** across snapshot rows is **1.6%**.

## Figures

### Revenue by month

![Revenue by month](eda/revenue_by_month.png)

### Revenue by category

![Revenue by category](eda/revenue_by_category.png)

### Pareto revenue curve

![Pareto revenue curve](eda/pareto_revenue.png)

### OTIF by supplier tier

![OTIF by supplier tier](eda/otif_by_tier.png)

### On-hand distribution

![On-hand distribution](eda/onhand_distribution.png)
